// 로컬 서버가 이 파일을 자동으로 대체합니다. 수정하지 마세요.
window.ICTC_CONFIG = { supabaseUrl: "", supabaseAnonKey: "" };
